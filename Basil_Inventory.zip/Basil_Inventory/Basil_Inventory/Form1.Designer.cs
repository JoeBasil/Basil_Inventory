﻿namespace Basil_Inventory
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBicycle = new System.Windows.Forms.TextBox();
            this.txtMower = new System.Windows.Forms.TextBox();
            this.txtGlove = new System.Windows.Forms.TextBox();
            this.txtCrackers = new System.Windows.Forms.TextBox();
            this.txtInvOut = new System.Windows.Forms.TextBox();
            this.txtOutputList = new System.Windows.Forms.TextBox();
            this.txtClear = new System.Windows.Forms.TextBox();
            this.btnBike = new System.Windows.Forms.Button();
            this.btnMower = new System.Windows.Forms.Button();
            this.btnGlove = new System.Windows.Forms.Button();
            this.btnCrackers = new System.Windows.Forms.Button();
            this.btnInv = new System.Windows.Forms.Button();
            this.btnMoney = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.lblLimit = new System.Windows.Forms.Label();
            this.txtList = new System.Windows.Forms.TextBox();
            this.txtBikeCounter = new System.Windows.Forms.TextBox();
            this.txtMowerCounter = new System.Windows.Forms.TextBox();
            this.txtGloveCounter = new System.Windows.Forms.TextBox();
            this.txtCrackersCounter = new System.Windows.Forms.TextBox();
            this.txtCostOut = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtBicycle
            // 
            this.txtBicycle.Location = new System.Drawing.Point(0, 0);
            this.txtBicycle.Name = "txtBicycle";
            this.txtBicycle.ReadOnly = true;
            this.txtBicycle.Size = new System.Drawing.Size(165, 20);
            this.txtBicycle.TabIndex = 0;
            this.txtBicycle.Text = "Press \"1\" To add Bicycle";
            // 
            // txtMower
            // 
            this.txtMower.Location = new System.Drawing.Point(0, 26);
            this.txtMower.Name = "txtMower";
            this.txtMower.ReadOnly = true;
            this.txtMower.Size = new System.Drawing.Size(165, 20);
            this.txtMower.TabIndex = 1;
            this.txtMower.Text = "Press \"2\" To add Mower";
            // 
            // txtGlove
            // 
            this.txtGlove.Location = new System.Drawing.Point(0, 52);
            this.txtGlove.Name = "txtGlove";
            this.txtGlove.ReadOnly = true;
            this.txtGlove.Size = new System.Drawing.Size(165, 20);
            this.txtGlove.TabIndex = 2;
            this.txtGlove.Text = "Press \"3\" To add Baseball Glove";
            // 
            // txtCrackers
            // 
            this.txtCrackers.Location = new System.Drawing.Point(0, 78);
            this.txtCrackers.Name = "txtCrackers";
            this.txtCrackers.ReadOnly = true;
            this.txtCrackers.Size = new System.Drawing.Size(165, 20);
            this.txtCrackers.TabIndex = 3;
            this.txtCrackers.Text = "Press \"4\" To add Crackers";
            // 
            // txtInvOut
            // 
            this.txtInvOut.Location = new System.Drawing.Point(0, 106);
            this.txtInvOut.Name = "txtInvOut";
            this.txtInvOut.ReadOnly = true;
            this.txtInvOut.Size = new System.Drawing.Size(165, 20);
            this.txtInvOut.TabIndex = 4;
            this.txtInvOut.Text = "Press \"5\" To Display Inventory";
            // 
            // txtOutputList
            // 
            this.txtOutputList.Location = new System.Drawing.Point(0, 132);
            this.txtOutputList.Name = "txtOutputList";
            this.txtOutputList.ReadOnly = true;
            this.txtOutputList.Size = new System.Drawing.Size(165, 20);
            this.txtOutputList.TabIndex = 5;
            this.txtOutputList.Text = "Press \"6\" To Show Charges";
            // 
            // txtClear
            // 
            this.txtClear.Location = new System.Drawing.Point(0, 158);
            this.txtClear.Name = "txtClear";
            this.txtClear.ReadOnly = true;
            this.txtClear.Size = new System.Drawing.Size(165, 20);
            this.txtClear.TabIndex = 6;
            this.txtClear.Text = "Press \"7\" To Clear inventory";
            // 
            // btnBike
            // 
            this.btnBike.Location = new System.Drawing.Point(171, 0);
            this.btnBike.Name = "btnBike";
            this.btnBike.Size = new System.Drawing.Size(75, 23);
            this.btnBike.TabIndex = 7;
            this.btnBike.Text = "1";
            this.btnBike.UseVisualStyleBackColor = true;
            this.btnBike.Click += new System.EventHandler(this.btnBike_Click);
            // 
            // btnMower
            // 
            this.btnMower.Location = new System.Drawing.Point(171, 23);
            this.btnMower.Name = "btnMower";
            this.btnMower.Size = new System.Drawing.Size(75, 23);
            this.btnMower.TabIndex = 8;
            this.btnMower.Text = "2";
            this.btnMower.UseVisualStyleBackColor = true;
            this.btnMower.Click += new System.EventHandler(this.btnMower_Click);
            // 
            // btnGlove
            // 
            this.btnGlove.Location = new System.Drawing.Point(171, 49);
            this.btnGlove.Name = "btnGlove";
            this.btnGlove.Size = new System.Drawing.Size(75, 23);
            this.btnGlove.TabIndex = 9;
            this.btnGlove.Text = "3";
            this.btnGlove.UseVisualStyleBackColor = true;
            this.btnGlove.Click += new System.EventHandler(this.btnGlove_Click);
            // 
            // btnCrackers
            // 
            this.btnCrackers.Location = new System.Drawing.Point(171, 75);
            this.btnCrackers.Name = "btnCrackers";
            this.btnCrackers.Size = new System.Drawing.Size(75, 23);
            this.btnCrackers.TabIndex = 10;
            this.btnCrackers.Text = "4";
            this.btnCrackers.UseVisualStyleBackColor = true;
            this.btnCrackers.Click += new System.EventHandler(this.btnCrackers_Click);
            // 
            // btnInv
            // 
            this.btnInv.Location = new System.Drawing.Point(171, 103);
            this.btnInv.Name = "btnInv";
            this.btnInv.Size = new System.Drawing.Size(75, 23);
            this.btnInv.TabIndex = 11;
            this.btnInv.Text = "5";
            this.btnInv.UseVisualStyleBackColor = true;
            this.btnInv.Click += new System.EventHandler(this.btnInv_Click);
            // 
            // btnMoney
            // 
            this.btnMoney.Location = new System.Drawing.Point(171, 129);
            this.btnMoney.Name = "btnMoney";
            this.btnMoney.Size = new System.Drawing.Size(75, 23);
            this.btnMoney.TabIndex = 12;
            this.btnMoney.Text = "6";
            this.btnMoney.UseVisualStyleBackColor = true;
            this.btnMoney.Click += new System.EventHandler(this.btnMoney_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(171, 155);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 13;
            this.btnClear.Text = "7";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtInput
            // 
            this.txtInput.Location = new System.Drawing.Point(252, 0);
            this.txtInput.Name = "txtInput";
            this.txtInput.ReadOnly = true;
            this.txtInput.Size = new System.Drawing.Size(95, 20);
            this.txtInput.TabIndex = 14;
            this.txtInput.TextChanged += new System.EventHandler(this.txtInput_TextChanged);
            // 
            // lblLimit
            // 
            this.lblLimit.AutoSize = true;
            this.lblLimit.Location = new System.Drawing.Point(9, 181);
            this.lblLimit.Name = "lblLimit";
            this.lblLimit.Size = new System.Drawing.Size(0, 13);
            this.lblLimit.TabIndex = 15;
            // 
            // txtList
            // 
            this.txtList.Location = new System.Drawing.Point(252, 23);
            this.txtList.Multiline = true;
            this.txtList.Name = "txtList";
            this.txtList.ReadOnly = true;
            this.txtList.Size = new System.Drawing.Size(162, 155);
            this.txtList.TabIndex = 16;
            this.txtList.TextChanged += new System.EventHandler(this.txtInputNum_TextChanged);
            // 
            // txtBikeCounter
            // 
            this.txtBikeCounter.Location = new System.Drawing.Point(893, 895);
            this.txtBikeCounter.Name = "txtBikeCounter";
            this.txtBikeCounter.Size = new System.Drawing.Size(18, 20);
            this.txtBikeCounter.TabIndex = 17;
            // 
            // txtMowerCounter
            // 
            this.txtMowerCounter.Location = new System.Drawing.Point(917, 895);
            this.txtMowerCounter.Name = "txtMowerCounter";
            this.txtMowerCounter.Size = new System.Drawing.Size(18, 20);
            this.txtMowerCounter.TabIndex = 18;
            // 
            // txtGloveCounter
            // 
            this.txtGloveCounter.Location = new System.Drawing.Point(941, 895);
            this.txtGloveCounter.Name = "txtGloveCounter";
            this.txtGloveCounter.Size = new System.Drawing.Size(20, 20);
            this.txtGloveCounter.TabIndex = 19;
            // 
            // txtCrackersCounter
            // 
            this.txtCrackersCounter.Location = new System.Drawing.Point(967, 895);
            this.txtCrackersCounter.Name = "txtCrackersCounter";
            this.txtCrackersCounter.Size = new System.Drawing.Size(21, 20);
            this.txtCrackersCounter.TabIndex = 20;
            // 
            // txtCostOut
            // 
            this.txtCostOut.Location = new System.Drawing.Point(353, 0);
            this.txtCostOut.Name = "txtCostOut";
            this.txtCostOut.ReadOnly = true;
            this.txtCostOut.Size = new System.Drawing.Size(61, 20);
            this.txtCostOut.TabIndex = 21;
            this.txtCostOut.TextChanged += new System.EventHandler(this.txtCostOut_TextChanged);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(416, 183);
            this.Controls.Add(this.txtCostOut);
            this.Controls.Add(this.txtCrackersCounter);
            this.Controls.Add(this.txtGloveCounter);
            this.Controls.Add(this.txtMowerCounter);
            this.Controls.Add(this.txtBikeCounter);
            this.Controls.Add(this.txtList);
            this.Controls.Add(this.lblLimit);
            this.Controls.Add(this.txtInput);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnMoney);
            this.Controls.Add(this.btnInv);
            this.Controls.Add(this.btnCrackers);
            this.Controls.Add(this.btnGlove);
            this.Controls.Add(this.btnMower);
            this.Controls.Add(this.btnBike);
            this.Controls.Add(this.txtClear);
            this.Controls.Add(this.txtOutputList);
            this.Controls.Add(this.txtInvOut);
            this.Controls.Add(this.txtCrackers);
            this.Controls.Add(this.txtGlove);
            this.Controls.Add(this.txtMower);
            this.Controls.Add(this.txtBicycle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.Text = "Inventory";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBicycle;
        private System.Windows.Forms.TextBox txtMower;
        private System.Windows.Forms.TextBox txtGlove;
        private System.Windows.Forms.TextBox txtCrackers;
        private System.Windows.Forms.TextBox txtInvOut;
        private System.Windows.Forms.TextBox txtOutputList;
        private System.Windows.Forms.TextBox txtClear;
        private System.Windows.Forms.Button btnBike;
        private System.Windows.Forms.Button btnMower;
        private System.Windows.Forms.Button btnGlove;
        private System.Windows.Forms.Button btnCrackers;
        private System.Windows.Forms.Button btnInv;
        private System.Windows.Forms.Button btnMoney;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Label lblLimit;
        private System.Windows.Forms.TextBox txtList;
        private System.Windows.Forms.TextBox txtBikeCounter;
        private System.Windows.Forms.TextBox txtMowerCounter;
        private System.Windows.Forms.TextBox txtGloveCounter;
        private System.Windows.Forms.TextBox txtCrackersCounter;
        private System.Windows.Forms.TextBox txtCostOut;
    }
}

