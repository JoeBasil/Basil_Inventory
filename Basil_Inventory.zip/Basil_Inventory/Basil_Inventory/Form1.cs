﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Basil_Inventory
{
    public partial class frmMain : Form
    {
        public frmMain()           
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
                 
        }        
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtInput.Text = "";
            btnMower.Enabled = true;
            btnGlove.Enabled = true;
            btnCrackers.Enabled = true;
            btnBike.Enabled = true;
            txtBikeCounter.Text = "";
            txtMowerCounter.Text = "";
            txtCrackersCounter.Text = "";
            txtGloveCounter.Text = "";
            txtList.Text = "";
        }

        private void btnBike_Click(object sender, EventArgs e)
        {
            txtInput.Text = txtInput.Text + "1" + " ";
            txtBikeCounter.Text = txtBikeCounter.Text + "1"; 

        }

        private void btnMower_Click(object sender, EventArgs e)
        {
            txtInput.Text = txtInput.Text + "2" + " ";
            txtMowerCounter.Text = txtMowerCounter.Text + "2";
        }

        private void btnGlove_Click(object sender, EventArgs e)
        {
            txtInput.Text = txtInput.Text + "3" + " ";
            txtGloveCounter.Text = txtGloveCounter.Text + "3";
        }

        private void btnCrackers_Click(object sender, EventArgs e)
        {
            txtInput.Text = txtInput.Text + "4" + " ";
            txtCrackersCounter.Text = txtCrackersCounter.Text + "4";
        }

        private void txtInput_TextChanged(object sender, EventArgs e)
        {
                
                if (txtInput.Text.Length > 19)
                    btnBike.Enabled = false;
                if (txtInput.Text.Length > 19)
                    btnCrackers.Enabled = false;
                if (txtInput.Text.Length > 19)
                    btnGlove.Enabled = false;
                if (txtInput.Text.Length > 19)
                    btnMower.Enabled = false;
                if (txtInput.Text.Length > 19)
                    lblLimit.Text = "You have reached your limit either press either 5/6/7 to continue";
        }

        private void btnInv_Click(object sender, EventArgs e)
        {
            int Bikenum = txtBikeCounter.Text.Length; 
            int Mowernum = txtMowerCounter.Text.Length;
            int Glovenum = txtGloveCounter.Text.Length;
            int Crackersnum = txtCrackersCounter.Text.Length;
            txtList.Text = Bikenum + "Bicycle(s)" + "/" + Mowernum + "Mower(s)" + Glovenum + "Gloves(s)" + "/" + Crackersnum + "Crackers";


        }

        private void btnMoney_Click(object sender, EventArgs e)
        {
            int Bikenum = txtBikeCounter.Text.Length;
            int Mowernum = txtMowerCounter.Text.Length;
            int Glovenum = txtGloveCounter.Text.Length;
            int Crackersnum = txtCrackersCounter.Text.Length;
            double Bikecost = Bikenum * 9.5;
            double Mowercost = Mowernum * 24;
            double Glovecost = Glovenum * 3.23;
            double Crackerscost = Crackersnum * .57;
            double Cost = Bikecost + Crackerscost + Mowercost + Glovecost;
            txtCostOut.Text = "$"+Cost.ToString();
        }

        private void txtInputNum_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCostOut_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
    

